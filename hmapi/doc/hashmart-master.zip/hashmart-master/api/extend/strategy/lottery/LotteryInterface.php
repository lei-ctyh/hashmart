<?php

namespace strategy\lottery;

interface LotteryInterface
{
    public function run($param);
}