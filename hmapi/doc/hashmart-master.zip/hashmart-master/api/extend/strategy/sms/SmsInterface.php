<?php

namespace strategy\sms;

interface SmsInterface
{
    public function send($param);
}