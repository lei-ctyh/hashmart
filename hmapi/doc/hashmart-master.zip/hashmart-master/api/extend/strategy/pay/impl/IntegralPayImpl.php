<?php

namespace strategy\pay\impl;

use strategy\pay\PayInterface;

class IntegralPayImpl implements PayInterface
{
    public function miniPay($param)
    {
        // TODO: Implement miniPay() method.
    }

    public function appPay($param)
    {
        // TODO: Implement appPay() method.
    }

    public function refund($param)
    {
        // TODO: Implement refund() method.
    }

    public function getConfig()
    {
        return [];
    }
}