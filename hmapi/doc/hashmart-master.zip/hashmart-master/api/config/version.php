<?php

return [
    // 版本号
    'version' => '1.0.1'
];