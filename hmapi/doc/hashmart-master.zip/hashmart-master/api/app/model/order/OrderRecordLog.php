<?php

namespace app\model\order;

use app\model\BaseModel;

class OrderRecordLog extends BaseModel
{

}