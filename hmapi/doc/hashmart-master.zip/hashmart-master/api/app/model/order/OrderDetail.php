<?php

namespace app\model\order;

use app\model\BaseModel;

class OrderDetail extends BaseModel
{

}