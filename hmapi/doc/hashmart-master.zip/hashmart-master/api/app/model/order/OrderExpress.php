<?php

namespace app\model\order;

use app\model\BaseModel;

class OrderExpress extends BaseModel
{

}