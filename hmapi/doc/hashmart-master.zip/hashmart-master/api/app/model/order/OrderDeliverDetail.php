<?php

namespace app\model\order;

use app\model\BaseModel;

class OrderDeliverDetail extends BaseModel
{

}