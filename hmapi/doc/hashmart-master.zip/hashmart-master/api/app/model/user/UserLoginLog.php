<?php

namespace app\model\user;

use app\model\BaseModel;

class UserLoginLog extends BaseModel
{

}