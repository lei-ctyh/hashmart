<?php

namespace app\model\user;

use app\model\BaseModel;

class UserBalanceRechargeLog extends BaseModel
{

}