<?php

namespace app\model\user;

use app\model\BaseModel;

class UserAgree extends BaseModel
{

}