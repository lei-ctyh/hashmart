<?php

namespace app\model\user;

use app\model\BaseModel;

class UserBalanceChangeLog extends BaseModel
{

}