<?php

namespace app\model\user;

use app\model\BaseModel;

class User extends BaseModel
{

}