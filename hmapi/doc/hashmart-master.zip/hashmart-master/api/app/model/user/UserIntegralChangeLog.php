<?php

namespace app\model\user;

use app\model\BaseModel;

class UserIntegralChangeLog extends BaseModel
{

}