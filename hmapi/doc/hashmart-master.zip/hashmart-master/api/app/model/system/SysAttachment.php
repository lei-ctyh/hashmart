<?php

namespace app\model\system;

use app\model\BaseModel;

class SysAttachment extends BaseModel
{

}