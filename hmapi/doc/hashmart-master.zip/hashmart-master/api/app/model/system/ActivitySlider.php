<?php

namespace app\model\system;

use app\model\BaseModel;

class ActivitySlider extends BaseModel
{

}