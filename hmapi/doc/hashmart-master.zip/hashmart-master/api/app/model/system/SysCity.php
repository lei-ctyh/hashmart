<?php

namespace app\model\system;

use app\model\BaseModel;

class SysCity extends BaseModel
{

}