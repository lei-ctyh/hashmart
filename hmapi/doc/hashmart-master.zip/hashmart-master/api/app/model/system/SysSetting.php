<?php

namespace app\model\system;

use app\model\BaseModel;

class SysSetting extends BaseModel
{

}