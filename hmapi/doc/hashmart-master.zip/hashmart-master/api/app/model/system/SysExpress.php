<?php

namespace app\model\system;

use app\model\BaseModel;

class SysExpress extends BaseModel
{

}