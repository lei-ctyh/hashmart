<?php

namespace app\model\system;

use app\model\BaseModel;

class SysAttachmentCate extends BaseModel
{

}