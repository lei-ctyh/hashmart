<?php

namespace app\model\goods;

use app\model\BaseModel;

class GoodsCate extends BaseModel
{

}