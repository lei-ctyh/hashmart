<?php

namespace app\model\goods;

use app\model\BaseModel;

class GoodsRuleExtend extends BaseModel
{

}