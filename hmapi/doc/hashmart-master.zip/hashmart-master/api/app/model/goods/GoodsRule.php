<?php

namespace app\model\goods;

use app\model\BaseModel;

class GoodsRule extends BaseModel
{

}