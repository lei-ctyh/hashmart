<?php

namespace app\model\box;

use app\model\BaseModel;

class BlindboxTag extends BaseModel
{

}